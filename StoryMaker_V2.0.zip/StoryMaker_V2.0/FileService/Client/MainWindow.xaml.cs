﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Windows.Forms;
using System.IO;


namespace Client
{
    public class File
    {
        public bool select { get; set; }
        public string fileName { get; set; }
    };
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public List<File> fil = new List<File>();
        string apiPath = "http://localhost:8381/api/File";

        public MainWindow()
        {
            InitializeComponent();
            //getFiles();
        }

        private void getFiles()
        {
            ClientT c = new ClientT(apiPath);
            string[] files = c.getAvailableFiles();

            fil = new List<File>();

            for (int i = 0; i < files.Length; i++)
            {
                File fi = new File();
                fi.select = false;
                fi.fileName = files[i];
                fil.Add(fi);
            }

            //lvUsers.ItemsSource = fil;
        }
        private void btnUploadfile_Click(object sender, RoutedEventArgs e)
        {
             

                System.Windows.Forms.OpenFileDialog ofd = new System.Windows.Forms.OpenFileDialog();
                ofd.Multiselect = true;
                System.Windows.Forms.DialogResult result = ofd.ShowDialog();
                string[] files = null;
                if (result == System.Windows.Forms.DialogResult.OK)
                {
                    files = ofd.FileNames;
                    if(files.Count()!=0)
                        TextBox1.Text = files[0];
                    
                }            
            
        }

        

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                ClientT c = new ClientT(apiPath);
                //foreach (var file in files)
                //{
                string file = TextBox1.Text.ToString();
                string text = file + TextBox2.Text.ToString() + TextBox3.Text.ToString() + TextBox4.Text.ToString();                
                c.upLoadFile(file);
                System.Windows.MessageBox.Show("File is uploaded");
                //}
            }
            catch (Exception ex)
            {
                System.Windows.MessageBox.Show("A exception just occurred and handled: " + ex.Message, "Exception Sample", MessageBoxButton.OK, MessageBoxImage.Warning);
            }

        }

        private void TextBox2_TextChanged(object sender, TextChangedEventArgs e)
        {
            string text = TextBox2.Text.ToString();
        }

        private void TextBox3_TextChanged(object sender, TextChangedEventArgs e)
        {
            string caption = TextBox3.Text.ToString();
        }

        private void TextBox4_TextChanged(object sender, TextChangedEventArgs e)
        {
            string description = TextBox4.Text.ToString();
        }

        
    }
}
