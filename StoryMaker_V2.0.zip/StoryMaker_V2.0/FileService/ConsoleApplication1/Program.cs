﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApplication1
{
    class Program
    {
        static void Main(string[] args)
        {
            string apiPath = "http://localhost:8899/api/File";
            ClientT c = new ClientT(apiPath);
            c.downLoadFile("bootstrap.min.css");

            c.upLoadFile("ClientT.cs");
        }
    }
}
