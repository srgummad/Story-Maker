﻿using Microsoft.Owin;
using Owin;

[assembly: OwinStartupAttribute(typeof(FileService.Startup))]
namespace FileService
{
    public partial class Startup
    {
        public void Configuration(IAppBuilder app)
        {
            ConfigureAuth(app);
        }
    }
}
