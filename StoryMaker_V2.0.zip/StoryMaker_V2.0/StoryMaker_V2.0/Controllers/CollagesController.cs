﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Mvc;
using StoryMaker_V2._0.Models;

namespace StoryMaker_V2._0.Controllers
{
    [HandleError]
    [Authorize]
    public class CollagesController : Controller
    {
        private StoryMaker_V2_0Context db = new StoryMaker_V2_0Context();

        // GET: Collages
        public ActionResult Index()
        {
            var collages = db.Collages.Include(c => c.Story);
            return View(collages.ToList());
        }

        // GET: Collages/Details/5
        public ActionResult Details(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Collage collage = db.Collages.Find(id);
            if (collage == null)
            {
                return HttpNotFound();
            }
            return View(collage);
        }

        // GET: Collages/Create
        public ActionResult Create()
        {
            ViewBag.storyId = new SelectList(db.Stories, "storyId", "storyName");
            return View();
        }

        // POST: Collages/Create
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create([Bind(Include = "collageId,collageName,collageDesc,createdDate,collageOrder,collageisArchived,collagePath,storyId")] Collage collage)
        {
            string path="~/StoriesRepo";
            string abspath=Server.MapPath(path);
            Story sobj_ = db.Stories.Find(collage.storyId);
            string sname = sobj_.storyName;
            string correctedname = sname.Replace(" ", "");
            string cpath = abspath + "\\" + correctedname;
            collage.collagePath = path+"/"+correctedname;
            string p=path+"/"+correctedname;
            string real = Server.MapPath(p);
            collage.collageisArchived = false; collage.createdDate = DateTime.Now;

            if (ModelState.IsValid)
            {
                db.Collages.Add(collage);
                db.SaveChanges();
                return RedirectToAction("Index");
            }

            ViewBag.storyId = new SelectList(db.Stories, "storyId", "storyName", collage.storyId);
            return View(collage);
        }

        // GET: Collages/Edit/5
        public ActionResult Edit(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Collage collage = db.Collages.Find(id);
            TempData["editCollage"] = collage;
            if (collage == null)
            {
                return HttpNotFound();
            }
            ViewBag.storyId = new SelectList(db.Stories, "storyId", "storyName", collage.storyId);
            return View(collage);
        }

        // POST: Collages/Edit/5
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit([Bind(Include = "collageId,collageName,collageDesc,createdDate,collageOrder,collageisArchived,collagePath,storyId")] Collage collage)
        {
            Collage col = (Collage)TempData["editCollage"];
            collage.createdDate = col.createdDate;
            collage.collageisArchived = col.collageisArchived;
            collage.collagePath = col.collagePath;
            collage.storyId = col.storyId;
            if (ModelState.IsValid)
            {
                db.Entry(collage).State = EntityState.Modified;
                db.SaveChanges();
                return RedirectToAction("Index");
            }
            ViewBag.storyId = new SelectList(db.Stories, "storyId", "storyName", collage.storyId);
            return View(collage);
        }

        // GET: Collages/Delete/5
        public ActionResult Delete(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Collage collage = db.Collages.Find(id);
            if (collage == null)
            {
                return HttpNotFound();
            }
            return View(collage);
        }

        // POST: Collages/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public ActionResult DeleteConfirmed(int id)
        {
            Collage collage = db.Collages.Find(id);
            db.Collages.Remove(collage);
            db.SaveChanges();
            return RedirectToAction("Index");
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}
