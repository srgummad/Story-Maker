﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace StoryMaker_V2._0.Controllers
{
    public class ErrorController : Controller
    {
        // GET: Error
        public ActionResult Index()
        {
            Response.StatusCode = 500;
            return View();
        }

        public ActionResult FrontendError()
        {
            Response.StatusCode = 404;
            return View();
        }

        public ActionResult BadRequest()
        {
            Response.StatusCode = 400;
            return View();
        }
            
        public ActionResult Unauthorized()
        {
            Response.StatusCode = 401;
            return View();
        }
        public ActionResult Forbidden()
        {
            Response.StatusCode = 403;
            return View();
        }
        public ActionResult Conflict()
        {
            Response.StatusCode = 409;
            return View();
        }
        public ActionResult Unavailable()
        {
            Response.StatusCode = 503;
            return View();
        }
    }
}