﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Text;
using System.Xml;
using System.Xml.Linq;

namespace StoryMaker_V2._0.Controllers
{
    [HandleError]
    public class HomeController : Controller
    {
        public ActionResult Index()
        {
            return View();
        }

        public ActionResult About()
        {
            ViewBag.Message = "Your application description page.";

            return View();
        }

        public ActionResult Contact()
        {
            ViewBag.Message = "Your contact page.";
            string path = "~/Content/Contact.xml";
            string fullpath = Server.MapPath(path);
            XDocument doc = XDocument.Load(fullpath);
            //var q = from x in doc.Elements("Contact").Elements("Person").Descendants() select x;
            Dictionary<string, string> contacts = new Dictionary<string, string>();
            var elems = from y in doc.Elements("Contact").Elements("Person").Elements() select y;
            foreach(var ps in elems)
            {
                
                  contacts.Add(ps.Name.ToString(), ps.Value.ToString());
                
            }
            ViewBag.contacts = contacts;
            
            //var els = from x in doc.Elements("Contact").Elements("Person").Elements("Name") select x;
            //foreach (var qq in els)
            //{
            //    ViewBag.Name = qq.Value;
            //    break;
            //}
            //var r = from x in doc.Elements("Contact").Elements("Person").Elements("Role") select x;
            //foreach (var rr in r)
            //{
            //    ViewBag.Role = rr.Value;
            //    break;
            //}
            //var e = from x in doc.Elements("Contact").Elements("Person").Elements("Email") select x;
            //foreach (var em in e)
            //{
            //    ViewBag.Email = em.Value;
            //    break;
            //}
            //var ph= from x in doc.Elements("Contact").Elements("Person").Elements("Phone") select x;
            //foreach (var pho in ph)
            //{
            //    ViewBag.Phone = pho.Value;
            //    break;
            //}

            
            return View(contacts);
        }

        public ActionResult Help()
        {
            return View();
        }
    }
}