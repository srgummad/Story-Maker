﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Mvc;
using StoryMaker_V2._0.Models;

namespace StoryMaker_V2._0.Controllers
{
    [HandleError]
    [Authorize]
    public class StoriesController : Controller
    {
        private StoryMaker_V2_0Context db = new StoryMaker_V2_0Context();

        // GET: Stories
        public ActionResult Index()
        {
            return View(db.Stories.ToList());
        }

        // GET: Stories/Details/5
        public ActionResult Details(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Story story = db.Stories.Find(id);
            if (story == null)
            {
                return HttpNotFound();
            }
            return View(story);
        }

        [Authorize(Roles="Dev")]
        // GET: Stories/Create
        public ActionResult Create()
        {
            return View();
        }

        // POST: Stories/Create
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [Authorize(Roles="Dev")]
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create([Bind(Include = "storyId,storyName,storyDate,storyisArchived,storyDescription")] Story story)
        {
            string path = "~/StoriesRepo";
            string abspath = Server.MapPath(path);
            string sName = story.storyName.Replace(" ", "");
            string storypath = abspath + "\\" + sName;
            System.IO.Directory.CreateDirectory(storypath);
            story.storyisArchived = false;
            story.storyDate = DateTime.Now;

            if (ModelState.IsValid)
            {
                db.Stories.Add(story);
                db.SaveChanges();
                return RedirectToAction("Index");
            }

            return View(story);
        }

        [Authorize(Roles="Dev")]
        // GET: Stories/Edit/5
        public ActionResult Edit(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Story story = db.Stories.Find(id);
            TempData["editStory"] = story;
            if (story == null)
            {
                return HttpNotFound();
            }
            return View(story);
        }

        // POST: Stories/Edit/5
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
         [Authorize(Roles = "Dev")]
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit([Bind(Include = "storyId,storyName,storyDate,storyisArchived,storyDescription")] Story story)
        {
            Story st = (Story)TempData["editStory"];
            story.storyDate = st.storyDate;
            story.storyisArchived = st.storyisArchived;
            if (ModelState.IsValid)
            {
                db.Entry(story).State = EntityState.Modified;
                db.SaveChanges();
                return RedirectToAction("Index");
            }
            return View(story);
        }

        [Authorize(Roles="Admin")]
        // GET: Stories/Delete/5
        public ActionResult Delete(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Story story = db.Stories.Find(id);
            if (story == null)
            {
                return HttpNotFound();
            }
            return View(story);
        }
         [Authorize(Roles = "Admin")]
        // POST: Stories/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public ActionResult DeleteConfirmed(int id)
        {
            Story story = db.Stories.Find(id);
            db.Stories.Remove(story);
            db.SaveChanges();
            return RedirectToAction("Index");
        }

        public ActionResult GenerateStory(int? id)
         {
             ViewBag.port = Request.Url.Port;
             ViewBag.id = id;             
             return View();
         }

        public ActionResult ViewStory(int? id,int? speed)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Story story = db.Stories.Find(id);
            string image = "";
            string desc = "";
            string caption = "";
            ICollection<Collage> collages = story.Collages;
            foreach(Collage col in collages)
            {
                IEnumerable<StoryBlock> sb = from x in col.StoryBlocks orderby x.sequenceNumber ascending select x ;
                int count = 0;
                foreach(StoryBlock s in sb)
                {
                    count++;
                    string temp = s.ImagePath;
                    int pos = temp.IndexOf("~");
                    string red = temp.Substring(1, temp.Length - 1);
                    string tempdesc = s.Description;
                    string tempcap = s.Caption;
                    
                    if(count==sb.Count())
                    {
                        image = image + red;
                        desc = desc + tempdesc;
                        caption = caption + tempcap;
                        continue;
                    }
                    image = image + red + ",";
                    desc = desc + tempdesc+"|}";
                    caption = caption + tempcap+"|}";
                }
            }
            ViewBag.Message = image;
            ViewBag.description = desc;
            ViewBag.capt = caption;
            ViewBag.speed = speed;
            return View();
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }
        [Authorize(Roles="Admin")]
        public ActionResult ArchiveStory(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Story story = db.Stories.Find(id);
            //ICollection<Collage> cols = story.Collages;
            //Collage coll = db.Collages.Find(id);
            //string s = coll.collageName;
            story.storyisArchived = true;
            ICollection<Collage> collages = story.Collages;
            foreach(var cl in collages)
            {
                cl.collageisArchived = true;
                ICollection<StoryBlock> sbs = cl.StoryBlocks;
                foreach (var sb in sbs)
                    sb.isArchived = true;
            }
                     
            db.SaveChanges();
            return RedirectToAction("Index");
        }

        public ActionResult ArchivedRepo()
        {
            return View(db.Stories.ToList());
        }

        public ActionResult UnArchive(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Story story = db.Stories.Find(id);
            //Collage coll = db.Collages.Find(id);
            //string s = coll.collageName;
            //story.storyisArchived = false;
            //coll.collageisArchived = false;
            story.storyisArchived = false;
            ICollection<Collage> collages = story.Collages;
            foreach (var cl in collages)
            {
                cl.collageisArchived = false;
                ICollection<StoryBlock> sbs = cl.StoryBlocks;
                foreach (var sb in sbs)
                    sb.isArchived = false;
            }

           

            db.SaveChanges();
            return RedirectToAction("ArchivedRepo");

        }
    }
}
