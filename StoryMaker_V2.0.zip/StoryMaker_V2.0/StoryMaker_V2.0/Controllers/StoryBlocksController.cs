﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Mvc;
using StoryMaker_V2._0.Models;

namespace StoryMaker_V2._0.Controllers
{
    [HandleError]
    [Authorize]
    public class StoryBlocksController : Controller
    {
        private StoryMaker_V2_0Context db = new StoryMaker_V2_0Context();

        // GET: StoryBlocks
        public ActionResult Index()
        {
            var storyBlocks = db.StoryBlocks.Include(s => s.Collage);
            return View(storyBlocks.ToList());
        }

        // GET: StoryBlocks/Details/5
        public ActionResult Details(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            StoryBlock storyBlock = db.StoryBlocks.Find(id);
            if (storyBlock == null)
            {
                return HttpNotFound();
            }
            return View(storyBlock);
        }

        // GET: StoryBlocks/Create
        public ActionResult Create()
        {
            ViewBag.collageId = new SelectList(db.Collages, "collageId", "collageName");
            return View();
        }

        // POST: StoryBlocks/Create
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create([Bind(Include = "BlockId,Name,Caption,Description,ImagePath,UploadDate,sequenceNumber,isArchived,collageId")] StoryBlock storyBlock, HttpPostedFileBase image)
        {
            string impath_ = image.FileName;
            Collage coll = db.Collages.Find(storyBlock.collageId);
            string storypath = coll.collagePath;
            string fullpath = Server.MapPath(storypath);
            fullpath = fullpath + "\\" + impath_;
            string relpath = storypath + "/" + impath_;
            storyBlock.ImagePath = relpath;
            image.SaveAs(fullpath);
            storyBlock.UploadDate = DateTime.Now;
            storyBlock.isArchived = false;

            if (ModelState.IsValid)
            {
                db.StoryBlocks.Add(storyBlock);
                db.SaveChanges();
                return RedirectToAction("Index");
            }

            ViewBag.collageId = new SelectList(db.Collages, "collageId", "collageName", storyBlock.collageId);
            return View(storyBlock);
        }

        // GET: StoryBlocks/Edit/5
        public ActionResult Edit(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            StoryBlock storyBlock = db.StoryBlocks.Find(id);
            TempData["editBlock"] = storyBlock;
            if (storyBlock == null)
            {
                return HttpNotFound();
            }
            ViewBag.collageId = new SelectList(db.Collages, "collageId", "collageName", storyBlock.collageId);
            return View(storyBlock);
        }

        // POST: StoryBlocks/Edit/5
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit([Bind(Include = "BlockId,Name,Caption,Description,ImagePath,UploadDate,sequenceNumber,isArchived,collageId")] StoryBlock storyBlock)
        {
            StoryBlock sb = (StoryBlock)TempData["editBlock"];
            storyBlock.ImagePath = sb.ImagePath;
            storyBlock.UploadDate = sb.UploadDate;
            storyBlock.isArchived = sb.isArchived;
            storyBlock.collageId = sb.collageId;
            
            
            
            if (ModelState.IsValid)
            {
                db.Entry(storyBlock).State = EntityState.Modified;
                db.SaveChanges();
                return RedirectToAction("Index");
            }
            ViewBag.collageId = new SelectList(db.Collages, "collageId", "collageName", storyBlock.collageId);
            return View(storyBlock);
        }

        // GET: StoryBlocks/Delete/5
        public ActionResult Delete(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            StoryBlock storyBlock = db.StoryBlocks.Find(id);
            if (storyBlock == null)
            {
                return HttpNotFound();
            }
            return View(storyBlock);
        }

        // POST: StoryBlocks/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public ActionResult DeleteConfirmed(int id)
        {
            StoryBlock storyBlock = db.StoryBlocks.Find(id);
            db.StoryBlocks.Remove(storyBlock);
            db.SaveChanges();
            return RedirectToAction("Index");
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}
