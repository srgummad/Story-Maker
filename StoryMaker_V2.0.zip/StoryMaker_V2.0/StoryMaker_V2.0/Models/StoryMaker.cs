﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.ComponentModel.DataAnnotations;

namespace StoryMaker_V2._0.Models
{
    public class StoryBlock
    {
        [Key]
        public int BlockId { get; set; }
        [Required]
        [Display(Name = "Block Name")]
        public string Name { get; set; }
        [Required]
        [Display(Name = "Caption")]
        public string Caption { get; set; }
        [Required]
        [Display(Name = "Description")]
        public string Description { get; set; }
        public string ImagePath { get; set; }
        [Required]
        [Display(Name = "Upload Date")]
        [DisplayFormat(DataFormatString = "{0:dd/MM/yyyy}", ApplyFormatInEditMode = true)]
        public DateTime UploadDate { get; set; }
        [Required]
        [Display(Name = "Block order")]
        public int sequenceNumber { get; set; }
        public bool isArchived { get; set; }
        public int collageId { get; set; }
        public virtual Collage Collage { get; set; }

    }

    public class Collage
    {
        [Key]
        public int collageId { get; set; }
        [Required]
        [Display(Name = "Collage Name")]
        public string collageName { get; set; }
        [Required]
        [Display(Name = "Description")]
        public string collageDesc { get; set; }
        [Required]
        [Display(Name = "Created Date")]
        [DisplayFormat(DataFormatString = "{0:dd/MM/yyyy}", ApplyFormatInEditMode = true)]
        public DateTime createdDate { get; set; }
        [Required]
        [Display(Name = "Collage Order")]
        public int collageOrder { get; set; }
        public bool collageisArchived { get; set; }
        public string collagePath { get; set; }

        public virtual ICollection<StoryBlock> StoryBlocks { get; set; }
        public int storyId { get; set; }
        public virtual Story Story { get; set; }


    }

    public class Story
    {
        [Key]
        public int storyId { get; set; }
        [Required]
        [Display(Name = "Story Name")]
        public string storyName { get; set; }
        [Required]
        [Display(Name = "Created Date")]
        [DisplayFormat(DataFormatString = "{0:dd/MM/yyyy}", ApplyFormatInEditMode = true)]
        public DateTime storyDate { get; set; }
        public bool storyisArchived { get; set; }
        public string storyDescription { get; set; }
        public virtual ICollection<Collage> Collages { get; set; }

    }
}