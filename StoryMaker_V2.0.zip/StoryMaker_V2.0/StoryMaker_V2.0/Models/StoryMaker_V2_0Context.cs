﻿using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Web;

namespace StoryMaker_V2._0.Models
{
    public class StoryMaker_V2_0Context : DbContext
    {
        // You can add custom code to this file. Changes will not be overwritten.
        // 
        // If you want Entity Framework to drop and regenerate your database
        // automatically whenever you change your model schema, please use data migrations.
        // For more information refer to the documentation:
        // http://msdn.microsoft.com/en-us/data/jj591621.aspx
    
        public StoryMaker_V2_0Context() : base("name=StoryMaker_V2_0Context")
        {
        }

        public System.Data.Entity.DbSet<StoryMaker_V2._0.Models.StoryBlock> StoryBlocks { get; set; }

        public System.Data.Entity.DbSet<StoryMaker_V2._0.Models.Collage> Collages { get; set; }

        public System.Data.Entity.DbSet<StoryMaker_V2._0.Models.Story> Stories { get; set; }
    
    }
}
