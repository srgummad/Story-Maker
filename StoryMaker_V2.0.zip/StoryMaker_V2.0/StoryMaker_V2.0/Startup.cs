﻿using Microsoft.Owin;
using Owin;

[assembly: OwinStartupAttribute(typeof(StoryMaker_V2._0.Startup))]
namespace StoryMaker_V2._0
{
    public partial class Startup
    {
        public void Configuration(IAppBuilder app)
        {
            ConfigureAuth(app);
        }
    }
}
